# CS 440 HW1 — Fall 2026

Due **Saturday, October 10, 2026, at 10:00 PM EST**.

1. Read **HW1.pdf** (the assignment and submission rules).
2. Choose **one** starter and extract it:
   - `cs440-a1-starter.zip`: Python 3.10 or newer.
   - `cs440-a1-cpp-starter.zip`: C++17 with g++ or clang++.
   - `cs440-a1-java-starter.zip`: Java, JDK 17 or newer.
3. Open the extracted starter's **README.md**. It lists the four files to edit,
   the API, and commands for checking each part.

**HW1-additional-info.pdf** is optional. It contains the worked grid dry run
and additional search diagrams; it adds no tasks or submission requirements.

All three starters use the same grids, questions, experiments, and grading.
Python 3.10 or newer runs the supplied checking and report tools for every
language. C++ and Java students do not need to write or understand Python.
No third-party libraries are required. Work individually or in a team of up to
four. Submit one language per team and add everyone to the Gradescope submission.

Run `python3 demo.py --tour` first. It works before you implement anything.
Then run `python3 autograder.py`. An untouched starter earns 3/55; TODO failures
are expected. The README explains how to produce the required report.pdf and
run `python3 submit.py` to create the submission zip (including hidden files). Written work and code review supply
the remaining 45 points.
